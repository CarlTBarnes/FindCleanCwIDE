These files are for testing code changes without affecting your real XML

Every XML file has an identical twin with an .XmlTEST extension
Copy_xmlTEST_OverXml.BAT will restore the unshrunk XML by doing a Copy XmlTEST over XML

B4Clean_Delete.Bat deletes all the Backup files and .TestShrink filesfile

Unzip this into a Folder named TextXML 
On the "/Config .Txt" Tab check the "Just This" box so only those folders are used



